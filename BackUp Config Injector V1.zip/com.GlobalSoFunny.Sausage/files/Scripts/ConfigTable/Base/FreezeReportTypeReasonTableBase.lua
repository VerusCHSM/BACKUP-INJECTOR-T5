local List0 = {
	[1] = {1,0,"外挂反馈","Cheating_response","系统检测到您存在违规游戏行为，破坏游戏环境\n现已实行<color=red>账号封停</color>处理"},
	[2] = {2,1,"坐挂车反馈","FlowCheating_reponse","由于您近期多次<color=red>主动与作弊玩家组队</color>，破坏游戏环境，现已进行<color=red>账号封停</color>处理"},
	[335544320] = {335544320,5,"退款封禁反馈","RefundFreeze_response","由于退款您的账号已被暂停使用"},
	[335544321] = {335544321,11,"第三方软件反馈","Malware_response","系统检测到您设备上存在作弊应用，为保护角色数据安全，现已实行<color=red>临时封停</color>处理，请及时卸载相关作弊应用，否则将面临永久封禁的处罚"},
	[335544322] = {335544322,12,"虚拟机反馈","VM_response","系统检测到您在虚拟机中运行游戏，为保护角色数据安全，现已实行<color=red>临时封停</color>处理，请不要在虚拟机环境中运行游戏，避免更严厉的处罚"},
	[838860800] = {838860800,2,"临时封禁反馈","TempFreeze_reponse","由于您账号数据异常，现已实行<color=red>临时封停处理</color>\n封停期间会再次核查该账号，若存在违规行为，则会永久封停；若无违规行为，则会自动解封"},
	[838860801] = {838860801,3,"身份证封禁反馈","IdentityFreeze_reponse","系统检测到您存在不良游戏行为，破坏游戏环境现已实行账号封停处理"},
	[872415232] = {872415232,4,"设备封禁反馈","DeviceIdFreeze_response","当前设备存在多次违规行为，已永久禁止登陆"},
	[1275068416] = {1275068416,6,"恶意托号反馈","MaliociousCarry_response","由于您近期存在<color=red>将作弊者带入高阶对局</color>的行为\n破坏游戏环境，现已实行<color=red>账号封停</color>处理"},
	[1275068417] = {1275068417,7,"连点器反馈","ContinousClicker_response","由于您<color=red>多次使用连点器</color>，破坏游戏环境公平\n现已实行<color=red>账号封停</color>处理"},
	[1275068418] = {1275068418,8,"绕检模拟器反馈","MaliciousSimulator_response","由于您<color=red>使用模拟器恶意绕检</color>，破坏游戏环境公平\n现已实行<color=red>账号封停</color>处理"},
	[1275068419] = {1275068419,9,"恶意组队反馈","MaliciousTeam_response","系统检测到您多次存在<color=red>恶意组队</color>行为，破坏游戏环境公平，现已实行<color=red>账号封停</color>处理"},
	[1275068420] = {1275068420,10,"外设反馈","ExteriorDevice_response","由于您<color=red>多次使用外设</color>，破坏游戏环境公平\n现已实行<color=red>账号封停</color>处理"},
}

local Keys = {1,2,335544320,335544321,335544322,838860800,838860801,872415232,1275068416,1275068417,1275068418,1275068419,1275068420,}



local FreezeReportTypeReasonTableBase = {

    -- 记录数
	COUNT = 13,

	-- 表
	List0 = List0,

	-- key集合
	Keys = Keys,



    -- 字段索引
	id = 1,
	reason_id = 2,
	name = 3,
	sign = 4,
	description = 5,

    -- 标识常量
	["Cheating_response"] = "Cheating_response",
	["FlowCheating_reponse"] = "FlowCheating_reponse",
	["RefundFreeze_response"] = "RefundFreeze_response",
	["Malware_response"] = "Malware_response",
	["VM_response"] = "VM_response",
	["TempFreeze_reponse"] = "TempFreeze_reponse",
	["IdentityFreeze_reponse"] = "IdentityFreeze_reponse",
	["DeviceIdFreeze_response"] = "DeviceIdFreeze_response",
	["MaliociousCarry_response"] = "MaliociousCarry_response",
	["ContinousClicker_response"] = "ContinousClicker_response",
	["MaliciousSimulator_response"] = "MaliciousSimulator_response",
	["MaliciousTeam_response"] = "MaliciousTeam_response",
	["ExteriorDevice_response"] = "ExteriorDevice_response",
}

if GlobalDefine.isGlobal then
    local languageColumns = {3, 5}
    local mt = {
        __index = function(self, key)
            if not key then
                return nil
            end
            return CS.Language.GetConfigContent(self[1000 + key])
        end,
        __metatable = "Don't edit metatable."
    }
    for k, v in pairs(List0) do
        v.__index = v
        for index, column in pairs(languageColumns) do
            v[1000 + column] = v[column]
            v[column] = nil
        end
        v.__metatable = "Don't edit metatable."
        setmetatable(v, mt)
    end
end

return FreezeReportTypeReasonTableBase