local List0 = {
	[603979776] = {603979776,1,1,8},
	[603979777] = {603979777,2,2,8},
	[603979778] = {603979778,3,3,8},
}

local Keys = {603979776,603979777,603979778,}



local FreezeSuspiciousPunishTableBase = {

    -- 记录数
	COUNT = 3,

	-- 表
	List0 = List0,

	-- key集合
	Keys = Keys,



    -- 字段索引
	id = 1,
	punish_type = 2,
	count = 3,
	punish_level = 4,

    -- 标识常量
}



return FreezeSuspiciousPunishTableBase