local List0 = {
	[1] = {1,1,12},
	[2] = {2,2,24},
	[3] = {3,3,48},
	[4] = {4,4,96},
	[5] = {5,5,168},
}

local Keys = {1,2,3,4,5,}



local EmulatorPunishLevelTableBase = {

    -- 记录数
	COUNT = 5,

	-- 表
	List0 = List0,

	-- key集合
	Keys = Keys,



    -- 字段索引
	id = 1,
	level = 2,
	duration = 3,

    -- 标识常量
}



return EmulatorPunishLevelTableBase