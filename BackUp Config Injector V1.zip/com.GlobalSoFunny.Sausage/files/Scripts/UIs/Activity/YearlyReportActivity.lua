local YearlyReportActivity = class({}, Assets.req("Scripts.UIs.UIBase"))
function YearlyReportActivity:initUI(ui)
    YearlyReportActivity.super.initUI(self, ui)
    self.components.BtnURL_Button.enabled = false
    self:addClickListener(self.components.BtnURL.myGameObject, table.handler(self, self.OnURLButtonClick))
    self.controllerManager.lobby:ProtoActivity(table.handler(self, self.OnRequestToken))
end

function YearlyReportActivity:RefreshUI(argData)
    self.data = argData
    self.components.Time.TxtTime_Text.text = TimeHelper:GetLocalDateFormat(TimeHelper.DateFormat1, argData.StartTime) .. "-" .. TimeHelper:GetLocalDateFormat(TimeHelper.DateFormat1, argData.EndTime)
    self.components.Explain.TxtExplain_Text.text = argData.Desc
end

function YearlyReportActivity:OnRequestToken()
    if self.controllerManager.lobby.trafficToken and self.controllerManager.lobby.trafficToken ~= "" then
        local token = UnityEngine.Networking.UnityWebRequest.EscapeURL(self.controllerManager.lobby.trafficToken)
        self.url = string.concat(CS.GeneralDefine.GetString("YearlyReportURL"), token)
        self.components.BtnURL_Button.enabled = true
    end
end

function YearlyReportActivity:OnURLButtonClick()
    if self.url then
        CS.UnityEngine.Application.OpenURL(self.url)
    end
end

return YearlyReportActivity
