local ReportPanel =
    class(
    {
        isMy = false,
        Role = nil,
        ReportRoleNameAndId = nil,
        ReportEndRole = nil,
        warId = 0,
        selCount = 0
    },
    Assets.req("Scripts.UIs.WindowBase")
)

function ReportPanel:initUI(ui)
    ReportPanel.super.initUI(self, ui)
    self.warId = 0
    self.selCount = 0
    --举报界面UI绑定
    self.ReportPanel = self.components.ReportBox
    self.ReportRoleDropdown = self.components.ReportSelectRolePanel.RoleDropdown_Dropdown
    self.ReportTogParent = self.components.ReportTogglePanel
    self.ReportCancelBtn = self.components.CancleReportBtn.myGameObject
    self.ReportSendBtn = self.components.SendReportBtn.myGameObject

    self.ReportShowTip = self.components.ReportTip.myGameObject
    self.ReportShowTipMsg = self.components.ReportTip.TipMsg_Text

    self.ReportRoleNameAndId = {}
    self.ReportEndRole = {}

    local function onCloseReportPanel()
        self:closeReportPanel()
    end
    self:addClickListener(self.ReportCancelBtn, onCloseReportPanel)
    --self:addClickListener(self.Mask, onCloseReportPanel)

    local function onReportSendBtn()
        self:sendReport()
    end
    self:addClickListener(self.ReportSendBtn, onReportSendBtn)
end

function ReportPanel:refreshTeamData(argWarId, argData, argReportBtnPanel)
    self.warId = argWarId
    self.myTeamRoleInfoList = argData
    self.ReportBtnPanel = argReportBtnPanel
end

--观战举报界面相关功能
function ReportPanel:openReportPanelForLookWar(argRoleInfo, argWarId, sendReportToUNet)
    self.warId = argWarId
    self.sendReportToUNet = sendReportToUNet
    self.ReportRoleDropdown.options:Clear()
    local tempData
    local teamRoleList = argRoleInfo
    for i = 0, teamRoleList.Length - 1 do
        local tempRoleTypeInfo = teamRoleList[i].RoleType
        tempData = UnityEngine.UI.Dropdown.OptionData()
        local roleUID = CS.Helper.PidToNewUid(teamRoleList[i].PlayerId)
        tempData.text = tempRoleTypeInfo .. teamRoleList[i].NickName .. " ID:" .. roleUID
        self.ReportRoleNameAndId[i] = {id = teamRoleList[i].PlayerId, name = teamRoleList[i].NickName}
        self.ReportRoleDropdown.options:Add(tempData)
    end

    if self.ReportRoleDropdown.options.Count > 0 then
        self.ReportRoleDropdown.value = 0
        self.ReportRoleDropdown.captionText.text = self.ReportRoleDropdown.options[0].text
    end
    self.ReportPanel.myGameObject:SetActive(true)
end

---举报界面
function ReportPanel:ToReportPlayer(argRoleInfoList, argWarId)
    self.warId = argWarId
    self.ReportRoleDropdown.options:Clear()
    local roleInfoList = argRoleInfoList
    for i = 1, #roleInfoList do
        local index = i - 1
        local tempData
        local roleInfo = roleInfoList[i]
        tempData = UnityEngine.UI.Dropdown.OptionData()
        local roleUID = CS.Helper.PidToNewUid(roleInfo.id)
        tempData.text = roleInfo.name .. " ID:" .. roleUID
        self.ReportRoleNameAndId[index] = {id = roleInfo.id, name = roleInfo.name}
        self.ReportRoleDropdown.options:Add(tempData)
    end
    if self.ReportRoleDropdown.options.Count > 0 then
        self.ReportRoleDropdown.value = 0
        self.ReportRoleDropdown.captionText.text = self.ReportRoleDropdown.options[0].text
    end
    self.ReportPanel.myGameObject:SetActive(true)
end
--举报界面相关功能
function ReportPanel:openReportPanel()
    if self.ReportBtnPanel then
        self.ReportBtnPanel:SetActive(false)
    end

    self.ReportRoleDropdown.options:Clear()
    local tempData

    local teamRoleList = self.myTeamRoleInfoList
    local tempIndex = 0
    for i = 0, teamRoleList.Length - 1 do
        local roleInfo = teamRoleList[i]
        if roleInfo.PlayerId ~= self._data.playerData.playerId then
            tempData = UnityEngine.UI.Dropdown.OptionData()
            local roleUID = CS.Helper.PidToNewUid(roleInfo.PlayerId)
            tempData.text = CS.Language.Get("A_ReportPanel_0") .. roleInfo.NickName .. " ID:" .. roleUID
            self.ReportRoleNameAndId[tempIndex] = {id = roleInfo.PlayerId, name = roleInfo.NickName}
            self.ReportRoleDropdown.options:Add(tempData)
            tempIndex = tempIndex + 1
        else
            if roleInfo.AttackRoleId ~= 0 and roleInfo.AttackRoleId ~= self._data.playerData.playerId then
                tempData = UnityEngine.UI.Dropdown.OptionData()
                local roleUID = CS.Helper.PidToNewUid(roleInfo.AttackRoleId)
                tempData.text = CS.Language.Get("A_ReportPanel_1") .. roleInfo.AttackRoleName .. " ID:" .. roleUID
                self.ReportRoleNameAndId[tempIndex] = {id = roleInfo.AttackRoleId, name = roleInfo.AttackRoleName}
                self.ReportRoleDropdown.options:Add(tempData)
                tempIndex = tempIndex + 1
            end
        end
    end

    if self.ReportRoleDropdown.options.Count > 0 then
        self.ReportRoleDropdown.value = 0
        self.ReportRoleDropdown.captionText.text = self.ReportRoleDropdown.options[0].text
    end

    self.ReportPanel.myGameObject:SetActive(true)
end

function ReportPanel:closeReportPanel()
    self:_colseAllTog()
    self.myController:close()
end

function ReportPanel:sendReport()
    local reportTogList = self:_getTogList()

    if #reportTogList < 1 then
        --self.ReportShowTip:SetActive(true)
        setNoticInfo(CS.Language.Get("A_ReportPanel_2"))
    else
        local index = self.ReportRoleDropdown.value
        if not self.ReportRoleNameAndId[index] then
            setNoticInfo(CS.Language.Get("A_ReportPanel_3"))
            self:closeReportPanel()
            return
        end
        local selectName = self.ReportRoleNameAndId[self.ReportRoleDropdown.value].name
        local selectId = self.ReportRoleNameAndId[self.ReportRoleDropdown.value].id
        if selectId ~= nil then
            local isReport = self:_isReoprt(selectId)
            if isReport == false then
                if selectId < 0 then
                    self.myController:Report(selectId, selectName, reportTogList, self.warId, self.myController.reportChannel)
                else
                    self.myController:Report(selectId, "", reportTogList, self.warId, self.myController.reportChannel)
                end

                self.ReportEndRole[#self.ReportEndRole + 1] = selectId

                if self.sendReportToUNet and selectId > 0 then
                    CS.LobbyHelper.Instance:SendReportRoleId(selectId)
                end
            end
        end
        setNoticInfo(CS.Language.Get("A_ReportPanel_3"))
        self:closeReportPanel()
    end
    -- self.ReportShowTip:SetActive(true)
    -- local onTime = function ()
    -- 	self.ReportShowTip:SetActive(false)
    -- end
    -- self:setTimeout(onTime, 1.7)
end

--通过选择的名字获得ID
function ReportPanel:_getRoleIdByName(dicNameAndId, name)
    if dicNameAndId ~= nil then
        for key, var in pairs(dicNameAndId) do
            if var == name then
                return key
            end
        end
    end
    return nil
end

--获得当前的选择项
function ReportPanel:_getTogList()
    local parentTsf = self.ReportTogParent.myTransform
    local reportTogList = {}
    for i = 0, parentTsf.childCount - 1 do
        local childTsf = parentTsf:GetChild(i)
        local childTog = childTsf:GetComponent("Toggle")
        if childTog.isOn then
            local togName = childTsf.name
            reportTogList[#reportTogList + 1] = togName
        end
    end
    return reportTogList
end

--关闭所有的选项
function ReportPanel:_colseAllTog()
    local parentTsf = self.ReportTogParent.myTransform
    for i = 0, parentTsf.childCount - 1 do
        local childTsf = parentTsf:GetChild(i)
        local childTog = childTsf:GetComponent("Toggle")
        childTog.isOn = false
    end
end

--检查重复举报
function ReportPanel:_isReoprt(selectId)
    local ReportEndCout = #self.ReportEndRole
    if ReportEndCout > 0 then
        for i = 1, #self.ReportEndRole do
            if self.ReportEndRole[i] == selectId then
                return true
            end
        end
        return false
    else
        return false
    end
end

return ReportPanel
